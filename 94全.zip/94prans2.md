## 「九十四年度高級中等以下學校及幼稚園教師資格檢定考試」選擇題參考答案

類別：特殊教育學校(班)

科目(組別)：教育原理與制度

<table><tr><td>題號</td><td>1</td><td>2</td><td>3</td><td>4</td><td>5</td><td>6</td><td>7</td><td>8</td><td>9</td><td>10</td></tr><tr><td>答案</td><td>(D)</td><td>(B)</td><td>(A)</td><td>(C)</td><td>(B)</td><td>(B)</td><td>(C)</td><td>(A)</td><td>(D)</td><td>(C)</td></tr></table>

<table><tr><td>題號</td><td>11</td><td>12</td><td>13</td><td>14</td><td>15</td><td>16</td><td>17</td><td>18</td><td>19</td><td>20</td></tr><tr><td>答案</td><td>(D)</td><td>(C)</td><td>(A)</td><td>(C)</td><td>(B)</td><td>(A)</td><td>(B)</td><td>(C)</td><td>(C)</td><td>(D)</td></tr></table>

<table><tr><td>題號</td><td>21</td><td>22</td><td>23</td><td>24</td><td>25</td><td>26</td><td>27</td><td>28</td><td>29</td><td>30</td></tr><tr><td>答案</td><td>(A)</td><td>(A)</td><td>(B)</td><td>(D)</td><td>(A)</td><td>(C)</td><td>(A)</td><td>(A)</td><td>(D)</td><td>(C)</td></tr></table>

<table><tr><td>題號</td><td>31</td><td>32</td><td>33</td><td>34</td><td>35</td><td>36</td><td>37</td><td>38</td><td>39</td><td>40</td></tr><tr><td>答案</td><td>(A)</td><td>(C)</td><td>(D)</td><td>(A)</td><td>(D)</td><td>(B)</td><td>(A)</td><td>(A)</td><td>(C)</td><td>(C)</td></tr></table>

![](images/c1b2da4c988485ff09063ac9743db946bc494336bfda2b6dd7fa7bef9ba673f5.jpg)
