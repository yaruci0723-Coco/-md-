## 「九十四年度高級中等以下學校及幼稚園教師資格檢定考試」選擇題參考答案

類別：特殊教育學校（班）

科目(組別)：特殊教育課程與教學—身心障礙組

<table><tr><td>題號</td><td>1</td><td>2</td><td>3</td><td>4</td><td>5</td><td>6</td><td>7</td><td>8</td><td>9</td><td>10</td></tr><tr><td>答案</td><td>B</td><td>D</td><td>D</td><td>B</td><td>A</td><td>C</td><td>A</td><td>C</td><td>D</td><td>A</td></tr></table>

<table><tr><td>題號</td><td>11</td><td>12</td><td>13</td><td>14</td><td>15</td><td>16</td><td>17</td><td>18</td><td>19</td><td>20</td></tr><tr><td>答案</td><td>A</td><td>C</td><td>B</td><td>D</td><td>C</td><td>A</td><td>D</td><td>C</td><td>B</td><td>A</td></tr></table>

<table><tr><td>題號</td><td>21</td><td>22</td><td>23</td><td>24</td><td>25</td><td>26</td><td>27</td><td>28</td><td>29</td><td>30</td></tr><tr><td>答案</td><td>B</td><td>C</td><td>C</td><td>D</td><td>D</td><td>C</td><td>B</td><td>B</td><td>A</td><td>B</td></tr></table>

<table><tr><td>題號</td><td>31</td><td>32</td><td>33</td><td>34</td><td>35</td></tr><tr><td>答案</td><td>D</td><td>D</td><td>A</td><td>C</td><td>B</td></tr></table>

![](images/6e136d6b41f982d62c3056e347ecb8bf6a3d8d2d08c997342d1b0b420beb0e63.jpg)
